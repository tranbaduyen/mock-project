/**
 * 
 */
package action;

import org.apache.struts.action.Action;

/**
 * @author HCD-Fresher161
 *
 */
public class DanhSachSuKienAction extends Action{

}
