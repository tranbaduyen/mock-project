package action;

import org.apache.struts.action.Action;

public class DanhSachNhanVatAction extends Action{

}
