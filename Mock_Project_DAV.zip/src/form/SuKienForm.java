/**
 * 
 */
package form;

import org.apache.struts.action.ActionForm;

/**
 * @author HCD-Fresher161
 *
 */
public class SuKienForm extends ActionForm{

}
