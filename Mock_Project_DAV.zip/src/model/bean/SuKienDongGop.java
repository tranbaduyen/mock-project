/**
 * 
 */
package model.bean;

/**
 * @author HCD-Fresher161
 *
 */
public class SuKienDongGop {

	private int maBDSK;
	private String maSuKien;
	private String userName;
	private String ngayDang;
	private String ten;
	private String nguon;
	private int pheDuyet;
	
	private String hinhDaiDien;
	
	
	public String getHinhDaiDien() {
		return hinhDaiDien;
	}
	public void setHinhDaiDien(String hinhDaiDien) {
		this.hinhDaiDien = hinhDaiDien;
	}
	/**
	 * @return the ten
	 */
	public String getTen() {
		return ten;
	}
	/**
	 * @param ten the ten to set
	 */
	public void setTen(String ten) {
		this.ten = ten;
	}
	/**
	 * @return the maBDSK
	 */
	public int getMaBDSK() {
		return maBDSK;
	}
	/**
	 * @param maBDSK the maBDSK to set
	 */
	public void setMaBDSK(int maBDSK) {
		this.maBDSK = maBDSK;
	}
	/**
	 * @return the maSuKien
	 */
	public String getMaSuKien() {
		return maSuKien;
	}
	/**
	 * @param maSuKien the maSuKien to set
	 */
	public void setMaSuKien(String maSuKien) {
		this.maSuKien = maSuKien;
	}
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * @return the ngayDang
	 */
	public String getNgayDang() {
		return ngayDang;
	}
	/**
	 * @param ngayDang the ngayDang to set
	 */
	public void setNgayDang(String ngayDang) {
		this.ngayDang = ngayDang;
	}
	/**
	 * @return the nguon
	 */
	public String getNguon() {
		return nguon;
	}
	/**
	 * @param nguon the nguon to set
	 */
	public void setNguon(String nguon) {
		this.nguon = nguon;
	}
	/**
	 * @return the pheDuyet
	 */
	public int getPheDuyet() {
		return pheDuyet;
	}
	/**
	 * @param pheDuyet the pheDuyet to set
	 */
	public void setPheDuyet(int pheDuyet) {
		this.pheDuyet = pheDuyet;
	}
	
	
	
}
