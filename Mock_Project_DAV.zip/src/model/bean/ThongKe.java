package model.bean;

public class ThongKe {
	
}
