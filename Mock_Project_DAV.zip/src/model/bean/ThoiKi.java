package model.bean;

public class ThoiKi {
	private int maThoiKi;
	private String tenThoiKi;
	private String noiDung;
	
	/**
	 * @return the maThoiKi
	 */
	public int getMaThoiKi() {
		return maThoiKi;
	}
	/**
	 * @param maThoiKi the maThoiKi to set
	 */
	public void setMaThoiKi(int maThoiKi) {
		this.maThoiKi = maThoiKi;
	}
	/**
	 * @return the tenThoiKi
	 */
	public String getTenThoiKi() {
		return tenThoiKi;
	}
	/**
	 * @param tenThoiKi the tenThoiKi to set
	 */
	public void setTenThoiKi(String tenThoiKi) {
		this.tenThoiKi = tenThoiKi;
	}
	/**
	 * @return the noiDung
	 */
	public String getNoiDung() {
		return noiDung;
	}
	/**
	 * @param noiDung the noiDung to set
	 */
	public void setNoiDung(String noiDung) {
		this.noiDung = noiDung;
	}
	
	
}
