package model.bean;

public class GiaiDoanNhanVat {

	private int maGDNV;
	private String tuNgay;
	private String denNgay;
	private String maGiaiDoan;

}
