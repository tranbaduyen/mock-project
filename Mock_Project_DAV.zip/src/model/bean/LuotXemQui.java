package model.bean;

public class LuotXemQui {
	private String mocThoiGian;
	private int soLuongSuKien;
	private int soLuongNhanVat;
	/**
	 * @return the period
	 */
	public String getMocThoiGian() {
		return mocThoiGian;
	}
	/**
	 * @param period the period to set
	 */
	public void setMocThoiGian(String mocThoiGian) {
		this.mocThoiGian = mocThoiGian;
	}
	/**
	 * @return the soLuongSuKien
	 */
	public int getSoLuongSuKien() {
		return soLuongSuKien;
	}
	/**
	 * @param soLuongSuKien the soLuongSuKien to set
	 */
	public void setSoLuongSuKien(int soLuongSuKien) {
		this.soLuongSuKien = soLuongSuKien;
	}
	/**
	 * @return the soLuongNhanVat
	 */
	public int getSoLuongNhanVat() {
		return soLuongNhanVat;
	}
	/**
	 * @param soLuongNhanVat the soLuongNhanVat to set
	 */
	public void setSoLuongNhanVat(int soLuongNhanVat) {
		this.soLuongNhanVat = soLuongNhanVat;
	}
	/**
	 * @return the soLuongDiaDanh
	 */
	
	
}
