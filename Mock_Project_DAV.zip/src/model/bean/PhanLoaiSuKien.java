package model.bean;

public class PhanLoaiSuKien {
	private int maPhanLoai;
	private String tenPhanLoai;
	/**
	 * @return the maPhanLoai
	 */
	public int getMaPhanLoai() {
		return maPhanLoai;
	}
	/**
	 * @param maPhanLoai the maPhanLoai to set
	 */
	public void setMaPhanLoai(int maPhanLoai) {
		this.maPhanLoai = maPhanLoai;
	}
	/**
	 * @return the tenPhanLoai
	 */
	public String getTenPhanLoai() {
		return tenPhanLoai;
	}
	/**
	 * @param tenPhanLoai the tenPhanLoai to set
	 */
	public void setTenPhanLoai(String tenPhanLoai) {
		this.tenPhanLoai = tenPhanLoai;
	}
	
	
}
