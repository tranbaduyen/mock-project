/**
 * 
 */
package model.bean;

/**
 * @author HCD-Fresher161
 *
 */
public class BinhLuan {
	private int maBinhLuan;
	private int maSuKien;
	private int maNhanVat;
	private int diemDanhGia;
	private String userName;
	private String ten;
	private String hinhDaiDien;
	private String tenBinhLuan;
	private String ngayBinhLuan;
	private String noiDung;
	private String nguon;
	private int pheDuyet;
	private String ngayDang;
	
	
	
	
	public String getNgayDang() {
		return ngayDang;
	}
	public void setNgayDang(String ngayDang) {
		this.ngayDang = ngayDang;
	}
	/**
	 * @return the ten
	 */
	public String getTen() {
		return ten;
	}
	/**
	 * @param ten the ten to set
	 */
	public void setTen(String ten) {
		this.ten = ten;
	}
	/**
	 * @return the hinhDaiDien
	 */
	public String getHinhDaiDien() {
		return hinhDaiDien;
	}
	/**
	 * @param hinhDaiDien the hinhDaiDien to set
	 */
	public void setHinhDaiDien(String hinhDaiDien) {
		this.hinhDaiDien = hinhDaiDien;
	}
	/**
	 * @return the maBinhLuan
	 */
	public int getMaBinhLuan() {
		return maBinhLuan;
	}
	/**
	 * @param maBinhLuan the maBinhLuan to set
	 */
	public void setMaBinhLuan(int maBinhLuan) {
		this.maBinhLuan = maBinhLuan;
	}
	/**
	 * @return the maSuKien
	 */
	public int getMaSuKien() {
		return maSuKien;
	}
	/**
	 * @param maSuKien the maSuKien to set
	 */
	public void setMaSuKien(int maSuKien) {
		this.maSuKien = maSuKien;
	}
	/**
	 * @return the maNhanVat
	 */
	public int getMaNhanVat() {
		return maNhanVat;
	}
	/**
	 * @param maNhanVat the maNhanVat to set
	 */
	public void setMaNhanVat(int maNhanVat) {
		this.maNhanVat = maNhanVat;
	}
	/**
	 * @return the diemDanhGia
	 */
	public int getDiemDanhGia() {
		return diemDanhGia;
	}
	/**
	 * @param diemDanhGia the diemDanhGia to set
	 */
	public void setDiemDanhGia(int diemDanhGia) {
		this.diemDanhGia = diemDanhGia;
	}
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * @return the tenBinhLuan
	 */
	public String getTenBinhLuan() {
		return tenBinhLuan;
	}
	/**
	 * @param tenBinhLuan the tenBinhLuan to set
	 */
	public void setTenBinhLuan(String tenBinhLuan) {
		this.tenBinhLuan = tenBinhLuan;
	}
	/**
	 * @return the ngayBinhLuan
	 */
	public String getNgayBinhLuan() {
		return ngayBinhLuan;
	}
	/**
	 * @param ngayBinhLuan the ngayBinhLuan to set
	 */
	public void setNgayBinhLuan(String ngayBinhLuan) {
		this.ngayBinhLuan = ngayBinhLuan;
	}
	/**
	 * @return the noiDung
	 */
	public String getNoiDung() {
		return noiDung;
	}
	/**
	 * @param noiDung the noiDung to set
	 */
	public void setNoiDung(String noiDung) {
		this.noiDung = noiDung;
	}
	/**
	 * @return the nguon
	 */
	public String getNguon() {
		return nguon;
	}
	/**
	 * @param nguon the nguon to set
	 */
	public void setNguon(String nguon) {
		this.nguon = nguon;
	}
	/**
	 * @return the pheDuyet
	 */
	public int getPheDuyet() {
		return pheDuyet;
	}
	/**
	 * @param pheDuyet the pheDuyet to set
	 */
	public void setPheDuyet(int pheDuyet) {
		this.pheDuyet = pheDuyet;
	}
	
	
}
