package model.bean;

public class NhanVatSuKien {
	private int maNVSK;
	private String tenNVSK;
	private String noiDung;
	private String ngayDau;
	private String ngayCuoi;
	private String hinhAnh;
	private String maThoiKy;
	private String tenThoiKy;
	private String maGiaiDoan;
	private String tenGiaiDoan;
	private int type;
	private String tenType;
	private String tenSuKien;
	private String maSuKien;
	
	
	
	public int getMaNVSK() {
		return maNVSK;
	}
	public void setMaNVSK(int maNVSK) {
		this.maNVSK = maNVSK;
	}
	public String getTenNVSK() {
		return tenNVSK;
	}
	public void setTenNVSK(String tenNVSK) {
		this.tenNVSK = tenNVSK;
	}
	public String getNoiDung() {
		return noiDung;
	}
	public void setNoiDung(String noiDung) {
		this.noiDung = noiDung;
	}
	public String getNgayDau() {
		return ngayDau;
	}
	public void setNgayDau(String ngayDau) {
		this.ngayDau = ngayDau;
	}
	public String getNgayCuoi() {
		return ngayCuoi;
	}
	public void setNgayCuoi(String ngayCuoi) {
		this.ngayCuoi = ngayCuoi;
	}
	public String getHinhAnh() {
		return hinhAnh;
	}
	public void setHinhAnh(String hinhAnh) {
		this.hinhAnh = hinhAnh;
	}
	public String getMaThoiKy() {
		return maThoiKy;
	}
	public void setMaThoiKy(String maThoiKy) {
		this.maThoiKy = maThoiKy;
	}
	public String getTenThoiKy() {
		return tenThoiKy;
	}
	public void setTenThoiKy(String tenThoiKy) {
		this.tenThoiKy = tenThoiKy;
	}
	public String getMaGiaiDoan() {
		return maGiaiDoan;
	}
	public void setMaGiaiDoan(String maGiaiDoan) {
		this.maGiaiDoan = maGiaiDoan;
	}
	public String getTenGiaiDoan() {
		return tenGiaiDoan;
	}
	public void setTenGiaiDoan(String tenGiaiDoan) {
		this.tenGiaiDoan = tenGiaiDoan;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public String getTenType() {
		return tenType;
	}
	public void setTenType(String tenType) {
		this.tenType = tenType;
	}
	public String getTenSuKien() {
		return tenSuKien;
	}
	public void setTenSuKien(String tenSuKien) {
		this.tenSuKien = tenSuKien;
	}
	public String getMaSuKien() {
		return maSuKien;
	}
	public void setMaSuKien(String maSuKien) {
		this.maSuKien = maSuKien;
	}

	
	

}
