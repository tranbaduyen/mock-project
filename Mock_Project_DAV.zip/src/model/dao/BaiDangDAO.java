package model.dao;

public class BaiDangDAO {

	public void themBaiDang(int maThoiKi) {
		// TODO Auto-generated method stub
		
	}

}
